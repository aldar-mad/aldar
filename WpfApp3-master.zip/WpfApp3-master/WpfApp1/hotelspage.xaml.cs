﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для hotelspage.xaml
    /// </summary>
    public partial class hotelspage : Page
    {
        public hotelspage()
        {
            InitializeComponent();
            DGridHotels.ItemsSource = praktikEntities.GetContext().Hotel.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            manager.Mainframe.Navigate(new addeditpage((sender as Button).DataContext as Hotel));
        }

        private void BtnEdit_click(object sender, RoutedEventArgs e)
        {
            manager.Mainframe.Navigate(new addeditpage(null));
        }

        private void BtnAdd_click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Clik(object sender, RoutedEventArgs e)
        {
            var hotelForRemoving = DGridHotels.SelectedItems.Cast<Hotel>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {hotelForRemoving.Count()} элементов?", "внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    praktikEntities.GetContext().Hotel.RemoveRange(hotelForRemoving);
                    praktikEntities.GetContext().SaveChanges();
                    MessageBox.Show("данные удалены!");

                    DGridHotels.ItemsSource = praktikEntities.GetContext().Hotel.ToList();
                }
                catch (Exception ex)
                
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChange(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                praktikEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridHotels.ItemsSource = praktikEntities.GetContext().Hotel.ToList();
            }
        }
    }
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           